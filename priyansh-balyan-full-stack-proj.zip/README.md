To run this project your node version must be above 6.8.0 and your browser must be ES6 compatible.

Install the required dependencies by typing ``npm install`` and start the project by typing ``npm start``.

After that you can access the server at http://localhost:5000/

Access the context menu by right clicking anywhere.

To delete a file or folder, right-click on its icon and select delete.

The selected item will be moved to trash.

To permanently delete the item, Click on trash and then right click on the item you want to delete and click delete.

Desktop files and folders are stored in a folder named ``desktop`` inside the project directory.

Files and folders in trash bin are stored in a folder named ``trash`` inside the project directory.